/**
* MyAnimation class, containing animation information
*/

export class MyAnimation {

    constructor(scene) {
        this.scene = scene;
    }

    update(t) {

    }

    apply(scene) {

    }
}